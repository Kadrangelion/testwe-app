import * as books from './books';
import * as characters from './characters';
import * as house from './house';

export {
  books,
  characters,
  house,
}