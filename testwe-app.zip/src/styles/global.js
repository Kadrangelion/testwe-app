import styled from 'styled-components';

export const PageContainer = styled.div`
  padding: 2rem;
`;